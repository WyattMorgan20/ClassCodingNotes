import java.io.*;
import java.util.*;

public class Exceptions 
{
   	public static void main(String[] args) throws IOException
	{
		int numIn;
		String fileName = "c:/0Temp/numbers.txt";
		Scanner myReader = new Scanner(new File(fileName));
		numIn = myReader.nextInt();
		System.out.println("number read = " + numIn);
		
	}
}
