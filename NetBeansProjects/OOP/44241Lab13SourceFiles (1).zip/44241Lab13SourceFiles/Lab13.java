/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package lab13;

/**
 *
 * @author CBADAMI
 */
public class Lab13 {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        Object[] objects = {new Lego(), new PogoStick(),
                            new LetterTray(), new EggCarton()};
        
        //Create your for loop here

    }
    
}
