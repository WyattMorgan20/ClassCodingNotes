/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/UnitTests/EmptyTestNGTest.java to edit this template
 */
package shopping;

import static org.testng.Assert.*;
import org.testng.annotations.AfterClass;
import org.testng.annotations.AfterMethod;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.Test;

/**
 * Class: 44542-02 Object-Oriented Programming
 *
 * @author Wyatt Morgan Description: Lab 06 NG Testing Due: 10/17/2024 I pledge
 * that I have completed the programming assignment independently. I have not
 * copied the code from a student or any source. I have not given my code to any
 * other student and will not share this code with anyone under my
 * circumstances.
 */

// this tests the product class
public class ProductNGTest {
    
    public ProductNGTest() {
    }

    @BeforeClass
    public static void setUpClass() throws Exception {
    }

    @AfterClass
    public static void tearDownClass() throws Exception {
    }

    @BeforeMethod
    public void setUpMethod() throws Exception {
    }

    @AfterMethod
    public void tearDownMethod() throws Exception {
    }

    /**
     * Test of getProductId method, of class Product.
     */
    @Test
    public void testGetProductId() {
        System.out.println("getProductId");
        Product instance = new Product("P1001", "Wireless Mouse", "Ergonomic wireless mouse with USB receiver", 25.99, 150, "Electronics");
        String expResult = "P1001";
        String result = instance.getProductId();
        assertEquals(result, expResult);
    }

    /**
     * Test of setProductId method, of class Product.
     */
    @Test
    public void testSetProductId() {
        System.out.println("setProductId");
        Product instance = new Product("P1001", "Wireless Mouse", "Ergonomic wireless mouse with USB receiver", 25.99, 150, "Electronics");
        String newProductId = "P1002";
        instance.setProductId(newProductId);
        assertEquals(instance.getProductId(), newProductId);
    }

    /**
     * Test of getName method, of class Product.
     */
    @Test
    public void testGetName() {
        System.out.println("getName");
        Product instance = new Product("P1001", "Wireless Mouse", "Ergonomic wireless mouse with USB receiver", 25.99, 150, "Electronics");
        String expResult = "Wireless Mouse";
        String result = instance.getName();
        assertEquals(result, expResult);
    }

    /**
     * Test of setName method, of class Product.
     */
    @Test
    public void testSetName() {
        System.out.println("setName");
        Product instance = new Product("P1001", "Wireless Mouse", "Ergonomic wireless mouse with USB receiver", 25.99, 150, "Electronics");
        String newName = "Bluetooth Keyboard";
        instance.setName(newName);
        assertEquals(instance.getName(), newName);
    }

    /**
     * Test of getDescription method, of class Product.
     */
    @Test
    public void testGetDescription() {
        System.out.println("getDescription");
        Product instance = new Product("P1001", "Wireless Mouse", "Ergonomic wireless mouse with USB receiver", 25.99, 150, "Electronics");
        String expResult = "Ergonomic wireless mouse with USB receiver";
        String result = instance.getDescription();
        assertEquals(result, expResult);
    }

    /**
     * Test of setDescription method, of class Product.
     */
    @Test
    public void testSetDescription() {
        System.out.println("setDescription");
        Product instance = new Product("P1001", "Wireless Mouse", "Ergonomic wireless mouse with USB receiver", 25.99, 150, "Electronics");
        String newDescription = "1m USB-C to USB-A cable";
        instance.setDescription(newDescription);
        assertEquals(instance.getDescription(), newDescription);
    }

    /**
     * Test of getPrice method, of class Product.
     */
    @Test
    public void testGetPrice() {
        System.out.println("getPrice");
        Product instance = new Product("P1001", "Wireless Mouse", "Ergonomic wireless mouse with USB receiver", 25.99, 150, "Electronics");
        double expResult = 25.99;
        double result = instance.getPrice();
        assertEquals(result, expResult, 0.0);
    }

    /**
     * Test of setPrice method, of class Product.
     */
    @Test
    public void testSetPrice() {
        System.out.println("setPrice");
        Product instance = new Product("P1001", "Wireless Mouse", "Ergonomic wireless mouse with USB receiver", 25.99, 150, "Electronics");
        double newPrice = 10.50;
        instance.setPrice(newPrice);
        assertEquals(instance.getPrice(), newPrice);
    }

    /**
     * Test of getStockQuantity method, of class Product.
     */
    @Test
    public void testGetStockQuantity() {
        System.out.println("getStockQuantity");
        Product instance = new Product("P1001", "Wireless Mouse", "Ergonomic wireless mouse with USB receiver", 25.99, 150, "Electronics");
        int expResult = 150;
        int result = instance.getStockQuantity();
        assertEquals(result, expResult);
    }

    /**
     * Test of setStockQuantity method, of class Product.
     */
    @Test
    public void testSetStockQuantity() {
        System.out.println("setStockQuantity");
        Product instance = new Product("P1001", "Wireless Mouse", "Ergonomic wireless mouse with USB receiver", 25.99, 150, "Electronics");
        int newStockQuantity = 200;
        instance.setStockQuantity(newStockQuantity);
        assertEquals(instance.getStockQuantity(), newStockQuantity);
    }

    /**
     * Test of getCategory method, of class Product.
     */
    @Test
    public void testGetCategory() {
        System.out.println("getCategory");
        Product instance = new Product("P1001", "Wireless Mouse", "Ergonomic wireless mouse with USB receiver", 25.99, 150, "Electronics");
        String expResult = "Electronics";
        String result = instance.getCategory();
        assertEquals(result, expResult);
    }

    /**
     * Test of setCategory method, of class Product.
     */
    @Test
    public void testSetCategory() {
        System.out.println("setCategory");
        Product instance = new Product("P1001", "Wireless Mouse", "Ergonomic wireless mouse with USB receiver", 25.99, 150, "Electronics");
        String newCategory = "Accessories";
        instance.setCategory(newCategory);
        assertEquals(instance.getCategory(), newCategory);
    }

    /**
     * Test of toString method, of class Product.
     */
    @Test
    public void testToString() {
        System.out.println("toString");
        Product instance = new Product("P1001", "Wireless Mouse", "Ergonomic wireless mouse with USB receiver", 25.99, 150, "Electronics");
        String expResult = "Product ID: P1001" + "\nName: Wireless Mouse" + "\nDescription: Ergonomic wireless mouse with USB receiver" + "\nPrice: $25.99" + "\nStock Quantity: 150" + "\nCategory: Electronics";
        String result = instance.toString();
        assertEquals(result, expResult);
    }
    
}
