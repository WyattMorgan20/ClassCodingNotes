/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/UnitTests/EmptyTestNGTest.java to edit this template
 */
package shopping;

import java.util.ArrayList;
import static org.testng.Assert.*;
import org.testng.annotations.AfterClass;
import org.testng.annotations.AfterMethod;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.Test;

/**
 * Class: 44542-02 Object-Oriented Programming
 *
 * @author Wyatt Morgan Description: Lab 06 NG Testing Due: 10/17/2024 I pledge
 * that I have completed the programming assignment independently. I have not
 * copied the code from a student or any source. I have not given my code to any
 * other student and will not share this code with anyone under my
 * circumstances.
 */

// this tests the order class
public class OrderNGTest {
    
    // initializing variables that will be used often here so I dont have to keep retyping them like I did in the Product test
    private Order order;
    private User user;
    private Product product1;
    private Product product2;
    private ArrayList<Product> products;
    
    public OrderNGTest() {
    }

    @BeforeClass
    public static void setUpClass() throws Exception {
    }

    @AfterClass
    public static void tearDownClass() throws Exception {
    }

    @BeforeMethod
    public void setUpMethod() throws Exception {
        // creating test products
        products = new ArrayList<>();

        products.add(new Product("P1001", "Wireless Mouse", "Ergonomic wireless mouse with USB receiver", 25.99, 150, "Electronics"));
        products.add(new Product("P1002", "USB-C Cable", "Durable USB-C charging cable", 10.50, 100, "Electronics"));

        // creating a test user
        user = new User("janesmith", "password456", "janesmith@example.com", "Jane Smith", "456 Elm St, Othertown, USA", "555-5678", new ShoppingCart(products));

        // initializing the order with test data
        order = new Order("O1001", user, products, "10/16/2024", "123 Main St", 71.98, "Processing");
    }

    @AfterMethod
    public void tearDownMethod() throws Exception {
        order = null;
        user = null;
        products = null;
    }

    /**
     * Test of getOrderId method, of class Order.
     */
    @Test
    public void testGetOrderId() {
        System.out.println("getOrderId");
        String expResult = "O1001";
        String result = order.getOrderId();
        assertEquals(result, expResult);
    }

    /**
     * Test of setOrderId method, of class Order.
     */
    @Test
    public void testSetOrderId() {
        System.out.println("setOrderId");
        String newOrderId = "O1002";
        order.setOrderId(newOrderId);
        assertEquals(order.getOrderId(), newOrderId);
    }

    /**
     * Test of getUser method, of class Order.
     */
    @Test
    public void testGetUser() {
        System.out.println("getUser");
        User result = order.getUser();
        assertEquals(result, user);
    }

    /**
     * Test of setUser method, of class Order.
     */
    @Test
    public void testSetUser() {
        System.out.println("setUser");
        User newUser = new User("newUser", "password", "new@example.com", "New User", "456 Main St", "0987654321", new ShoppingCart());
        order.setUser(newUser);
        assertEquals(order.getUser(), newUser, "User was not set correctly.");
    }

    /**
     * Test of getProducts method, of class Order.
     */
    @Test
    public void testGetProducts() {
        System.out.println("getProducts");
        assertEquals(order.getProducts(), products, "Expected products do not match.");
    }

    /**
     * Test of setProducts method, of class Order.
     */
    @Test
    public void testSetProducts() {
        System.out.println("setProducts");
        ArrayList<Product> newProducts = new ArrayList<>();
        newProducts.add(new Product("P1003", "Bluetooth Keyboard", "Compact Bluetooth keyboard with rechargeable battery", 45.00, 100, "Electronics"));
        order.setProducts(newProducts);
        assertEquals(order.getProducts(), newProducts, "Products were not set correctly.");
    }

    /**
     * Test of getOrderDate method, of class Order.
     */
    @Test
    public void testGetOrderDate() {
        System.out.println("getOrderDate");
        assertEquals(order.getOrderDate(), "10/16/2024", "Expected order date does not match.");
    }

    /**
     * Test of setOrderDate method, of class Order.
     */
    @Test
    public void testSetOrderDate() {
        System.out.println("setOrderDate");
        order.setOrderDate("10/17/2024");
        assertEquals(order.getOrderDate(), "10/17/2024", "Order date was not set correctly.");
    }

    /**
     * Test of getShippingAddress method, of class Order.
     */
    @Test
    public void testGetShippingAddress() {
        System.out.println("getShippingAddress");
        assertEquals(order.getShippingAddress(), "123 Main St", "Expected shipping address does not match.");
    }

    /**
     * Test of setShippingAddress method, of class Order.
     */
    @Test
    public void testSetShippingAddress() {
        System.out.println("setShippingAddress");
        order.setShippingAddress("456 Elm St");
        assertEquals(order.getShippingAddress(), "456 Elm St", "Shipping address was not set correctly.");
    }

    /**
     * Test of getTotalAmount method, of class Order.
     */
    @Test
    public void testGetTotalAmount() {
        System.out.println("getTotalAmount");
        assertEquals(order.getTotalAmount(), 71.98, "Expected total amount does not match.");
    }

    /**
     * Test of setTotalAmount method, of class Order.
     */
    @Test
    public void testSetTotalAmount() {
        System.out.println("setTotalAmount");
        order.setTotalAmount(80.00);
        assertEquals(order.getTotalAmount(), 80.00, "Total amount was not set correctly.");
    }

    /**
     * Test of getStatus method, of class Order.
     */
    @Test
    public void testGetStatus() {
        System.out.println("getStatus");
        assertEquals(order.getStatus(), "Processing", "Expected status does not match.");
    }

    /**
     * Test of setStatus method, of class Order.
     */
    @Test
    public void testSetStatus() {
        System.out.println("setStatus");
        order.setStatus("Shipped");
        assertEquals(order.getStatus(), "Shipped", "Status was not set correctly.");
    }

    /**
     * Test of toString method, of class Order.
     */
    @Test
    public void testToString() {
        System.out.println("toString");
        String expectedOutput = "Order ID: O1001\n" + user + "\nOrder Date: 10/16/2024\nShipping Address: 123 Main St\nStatus: Processing" + "\nProducts:\n1. Wireless Mouse - $29.99\n2. USB-C Cable - $10.5\nTotal Amount: $71.98";
        assertEquals(order.toString(), expectedOutput, "toString output does not match expected output.");
    }

    /**
     * Test of placeOrder method, of class Order.
     */
    @Test
    public void testPlaceOrder() {
        System.out.println("placeOrder");
        Order result = Order.placeOrder(user);
        assertNotNull(result, "Order should not be null after placing.");
        assertEquals(result.getUser(), user, "Placed order user does not match.");
        assertEquals(result.getStatus(), "Placed", "Order status should be 'Placed' after placement.");
        assertEquals(result.getShippingAddress(), user.getAddress(), "Shipping address should match user's address.");
        double delta = 0.001;
        assertEquals(result.getTotalAmount(), user.getCart().getTotalAmount(), delta, "Total amount should match user's cart total.");
    }
    
}
