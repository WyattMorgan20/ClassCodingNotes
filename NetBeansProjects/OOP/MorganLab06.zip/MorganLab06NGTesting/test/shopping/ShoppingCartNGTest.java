/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/UnitTests/EmptyTestNGTest.java to edit this template
 */
package shopping;

import java.util.ArrayList;
import static org.testng.Assert.*;
import org.testng.annotations.AfterClass;
import org.testng.annotations.AfterMethod;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.Test;

/**
 * Class: 44542-02 Object-Oriented Programming
 *
 * @author Wyatt Morgan Description: Lab 06 NG Testing Due: 10/17/2024 I pledge
 * that I have completed the programming assignment independently. I have not
 * copied the code from a student or any source. I have not given my code to any
 * other student and will not share this code with anyone under my
 * circumstances.
 */

// this tests the shoppingcart class
public class ShoppingCartNGTest {
    // initializing variables that will be used often here so I dont have to keep retyping them like I did in the Product test
    private ShoppingCart cart;
    private Product product1;
    private Product product2;
    
    public ShoppingCartNGTest() {
    }

    @BeforeClass
    public static void setUpClass() throws Exception {
    }

    @AfterClass
    public static void tearDownClass() throws Exception {
    }

    @BeforeMethod
    public void setUpMethod() throws Exception {
        cart = new ShoppingCart();
        product1 = new Product("P1001", "Wireless Mouse", "Ergonomic wireless mouse with USB receiver", 25.99, 150, "Electronics");
        product2 = new Product("P1002", "USB-C Cable", "Durable USB-C charging cable", 10.50, 100, "Electronics");
    }

    @AfterMethod
    public void tearDownMethod() throws Exception {
        cart = null;
    }

    /**
     * Test of getItems method, of class ShoppingCart.
     */
    @Test
    public void testGetItems() {
        System.out.println("getItems");
        ArrayList result = cart.getItems();
        assertNotNull(result);
        assertTrue(result.isEmpty());
    }

    /**
     * Test of setItems method, of class ShoppingCart.
     */
    @Test
    public void testSetItems() {
        System.out.println("setItems");
        ArrayList<Product> items = new ArrayList<>();
        items.add(product1);
        cart.setItems(items);
        assertEquals(cart.getItems().size(), 1);
    }

    /**
     * Test of getTotalAmount method, of class ShoppingCart.
     */
    @Test
    public void testGetTotalAmount() {
        System.out.println("getTotalAmount");
        double result = cart.getTotalAmount();
        assertEquals(result, 0.0, 0.0);
    }

    /**
     * Test of setTotalAmount method, of class ShoppingCart.
     */
    @Test
    public void testSetTotalAmount() {
        System.out.println("setTotalAmount");
        double totalAmount = 36.49;
        cart.setTotalAmount(totalAmount);
        assertEquals(cart.getTotalAmount(), totalAmount);
    }

    /**
     * Test of addProduct method, of class ShoppingCart.
     */
    @Test
    public void testAddProduct() {
        System.out.println("addProduct");
        cart.addProduct(product1);
        assertEquals(cart.getItems().size(), 1);
        assertEquals(cart.getTotalAmount(), 25.99, 0.001);
    }

    /**
     * Test of removeProduct method, of class ShoppingCart.
     */
    @Test
    public void testRemoveProduct() {
        System.out.println("removeProduct");
        cart.addProduct(product1);
        cart.addProduct(product2);
        cart.removeProduct("P1001");
        assertEquals(cart.getItems().size(), 2);
        assertEquals(cart.getTotalAmount(), 36.49, 0.001);
    }

    /**
     * Test of calculateTotal method, of class ShoppingCart.
     */
    @Test
    public void testCalculateTotal() {
        System.out.println("calculateTotal");
        cart.addProduct(product1);
        cart.addProduct(product2);
        cart.calculateTotal();
        assertEquals(cart.getTotalAmount(), 36.49, 0.001);
    }

    /**
     * Test of toString method, of class ShoppingCart.
     */
    @Test
    public void testToString() {
        System.out.println("toString");
        cart.addProduct(product1);
        cart.addProduct(product2);
        String result = cart.toString();
        String expResult = "Shopping Cart:\n" + "1. Wireless Mouse - $25.99\n" + "2. USB-C Cable - $10.50\n" + "Total Amount: $36.49";
        assertEquals(result, expResult);
    }
    
}
