/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package shopping;

import java.util.ArrayList;

/**
 * Class: 44542-02 Object-Oriented Programming
 *
 * @author Wyatt Morgan Description: Lab 06 NG Testing Due: 10/17/2024 I pledge
 * that I have completed the programming assignment independently. I have not
 * copied the code from a student or any source. I have not given my code to any
 * other student and will not share this code with anyone under my
 * circumstances.
 */

// this adds and removes items from the cart, houses the cart, calculates the total cost of all the items in the cart, etc
public class ShoppingCart {

    // initializing variables
    private ArrayList<Product> items = new ArrayList<>();
    private double totalAmount;

    // creating constructor
    public ShoppingCart() {
        this.items = new ArrayList<>();
        this.totalAmount = 0.0;
    }
    
    // I had to make this to fix an issue with my test code:
    public ShoppingCart(ArrayList<Product> items){
        this.items = items;
        calculateTotal();
    }

    // Start of getter setter methods:
    /**
     * @return the items
     */
    public ArrayList<Product> getItems() {
        return items;
    }

    /**
     * @param items the items to set
     */
    public void setItems(ArrayList<Product> items) {
        this.items = items;
    }

    /**
     * @return the totalAmount
     */
    public double getTotalAmount() {
        return totalAmount;
    }

    /**
     * @param totalAmount the totalAmount to set
     */
    public void setTotalAmount(double totalAmount) {
        this.totalAmount = totalAmount;
    }

    public void addProduct(Product product) {
        items.add(product);
        calculateTotal();
    }

    public void removeProduct(String productId) {
        items.remove(productId);
        calculateTotal();
    }

    public double calculateTotal() {
        totalAmount = 0.0;
        for (Product product : items) {
            totalAmount += product.getPrice();
        }
        return totalAmount;
    }
    // end of getter setter methods^

    // toString:
    // iterating through the shopping cart's (items) array list and adding them and their price to the string output
    @Override
    public String toString() {
        String output = "Shopping Cart:\n";
        for (int i = 0; i < items.size(); i++) {
            Product product = items.get(i);
            output += (i + 1) + ". " + product.getName() + " - $" + product.getPrice() + "\n";
        }
        output += "Total Amount: $" + totalAmount;

        return output;
    }
}
