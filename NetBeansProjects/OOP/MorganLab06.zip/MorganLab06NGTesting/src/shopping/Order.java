/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package shopping;

import java.util.ArrayList;

/**
 * Class: 44542-02 Object-Oriented Programming
 *
 * @author Wyatt Morgan Description: Lab 06 NG Testing Due: 10/17/2024 I pledge
 * that I have completed the programming assignment independently. I have not
 * copied the code from a student or any source. I have not given my code to any
 * other student and will not share this code with anyone under my
 * circumstances.
 */

// this creates orders, calculates the totalamount of cost for every item in the cart, and provides most all of the order data in terms of user info and product info
public class Order {

    // initializing variables
    private String orderId;
    private User user;
    private ArrayList<Product> products = new ArrayList<>();
    private String orderDate;
    private String shippingAddress;
    private double totalAmount;
    private String status;

    // creating constructor
    public Order(String orderId, User user, ArrayList<Product> products, String orderDate, String shippingAddress, double totalAmount, String status) {
        this.orderId = orderId;
        this.user = user;
        this.products = products;
        this.orderDate = orderDate;
        this.shippingAddress = shippingAddress;
        this.totalAmount = totalAmount;
        this.status = status;
    }

    // Start of getter setter methods:
    /**
     * @return the orderId
     */
    public String getOrderId() {
        return orderId;
    }

    /**
     * @param orderId the orderId to set
     */
    public void setOrderId(String orderId) {
        this.orderId = orderId;
    }

    /**
     * @return the user
     */
    public User getUser() {
        return user;
    }

    /**
     * @param user the user to set
     */
    public void setUser(User user) {
        this.user = user;
    }

    /**
     * @return the products
     */
    public ArrayList<Product> getProducts() {
        return products;
    }

    /**
     * @param products the products to set
     */
    public void setProducts(ArrayList<Product> products) {
        this.products = products;
    }

    /**
     * @return the orderDate
     */
    public String getOrderDate() {
        return orderDate;
    }

    /**
     * @param orderDate the orderDate to set
     */
    public void setOrderDate(String orderDate) {
        this.orderDate = orderDate;
    }

    /**
     * @return the shippingAddress
     */
    public String getShippingAddress() {
        return shippingAddress;
    }

    /**
     * @param shippingAddress the shippingAddress to set
     */
    public void setShippingAddress(String shippingAddress) {
        this.shippingAddress = shippingAddress;
    }

    /**
     * @return the totalAmount
     */
    public double getTotalAmount() {
        return totalAmount;
    }

    /**
     * @param totalAmount the totalAmount to set
     */
    public void setTotalAmount(double totalAmount) {
        this.totalAmount = totalAmount;
    }

    /**
     * @return the status
     */
    public String getStatus() {
        return status;
    }

    /**
     * @param status the status to set
     */
    public void setStatus(String status) {
        this.status = status;
    }
    // end of getter setter methods^

    // toString:
    // iterating through the shopping cart's (items) array list and adding them and their price to the string output
    @Override
    public String toString() {
        String output = "Products:\n";
        for (int i = 0; i < products.size(); i++) {
            Product product = products.get(i);
            output += (i + 1) + ". " + product.getName() + " - $" + product.getPrice() + "\n";
        }
        output += "Total Amount: $" + totalAmount;

        return "Order ID: " + orderId + "\n" + user + "\nOrder Date: " + orderDate + "\nShipping Address: " + shippingAddress + "\nStatus: " + status + "\n" + output;
    }

    public static Order placeOrder(User user) {
        // creating a random number for the Id to make it unique and making it the orderId
        int Id = (int) (Math.random() * 1000);
        String orderId = "O" + Id;
        
        ArrayList<Product> products = user.getCart().getItems();
        double totalAmount = user.getCart().calculateTotal();
        
        // creating the rest of the cart items
        String orderDate = "10/16/2024";
        String shippingAddress = user.getAddress();
        String status = "Placed";

        // creating order object
        Order order = new Order(orderId, user, products, orderDate, shippingAddress, totalAmount, status);

        // updating the product stock amounts
        for (Product product : products) {
            product.setStockQuantity(product.getStockQuantity() - 1);
        }

        // clearing shopping cart
        user.getCart().getItems().clear();
        user.getCart().calculateTotal();

        return order;
    }
}
