package interfaceexamplestudentfiles;

/*
 * @author merry
 * @version Feb 22, 2007
 */

public class Undergraduate 
{
	public Undergraduate()
	{
		super();
	}
	
	public Undergraduate(String firstName, String lastName, double gpa)
	{
		super(firstName, lastName, gpa);
	}

}
