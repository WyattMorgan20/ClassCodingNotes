package interfaceexamplestudentfiles;

/**
 *
 * @author merry
 */
public class FullTimeEmployee 
{
	private String firstName;
	private String lastName;
	private double annualSalary;

	public FullTimeEmployee()
	{
		this("", "", 0.0);
	}

	public FullTimeEmployee(String firstName, String lastName,
		double annualSalary)
	{
		this.firstName = firstName;
		this.lastName = lastName;
		this.annualSalary = annualSalary;
	}


}
