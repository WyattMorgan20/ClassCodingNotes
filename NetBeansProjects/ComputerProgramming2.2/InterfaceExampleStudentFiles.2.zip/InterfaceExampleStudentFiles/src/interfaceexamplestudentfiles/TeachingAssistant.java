package interfaceexamplestudentfiles;

/**
 *
 * @author merry
 */
public class TeachingAssistant
{
	private double semesterStipend;

	public TeachingAssistant()
	{
		super();
		semesterStipend = 0.0;
	}

	public TeachingAssistant(double semesterStipend)
	{
		this.semesterStipend = semesterStipend;
	}

	public TeachingAssistant(String firstName, String lastName,
		double gpa, boolean admittedToCandidacy, double semesterStipend)
	{
		super(firstName, lastName, gpa, admittedToCandidacy);
		this.semesterStipend = semesterStipend;
	}

}
