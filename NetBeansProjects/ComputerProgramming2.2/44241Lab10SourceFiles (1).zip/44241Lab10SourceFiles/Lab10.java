/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package lab10;

/**
 *
 * @author CBADAMI
 */
public class Lab10
{

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        //1. Add your name and date here
        
        //2. Create an instance of Refrigerator (fridgeA)
        //3. Create a second instance of Refrigerator (fridgeB)
        //4. Create an instance of Washer (washerA)
        //5. Create a second instance of Washer (washerB)
        
        System.out.println("Refrigerator info:\n");
        
        //6. Print the info for fridgeA and fridgeB, with labels to match output
        //      (see lab instructions)

        
        System.out.println("\nWasher info:\n");
        
        //7. Print the info for washerA and washerB, with labels to match output
        //      (see lab instructions)
        

    }
    
}
