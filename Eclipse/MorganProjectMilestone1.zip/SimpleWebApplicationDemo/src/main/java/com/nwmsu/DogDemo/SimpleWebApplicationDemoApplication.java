package com.nwmsu.DogDemo;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class SimpleWebApplicationDemoApplication {

	public static void main(String[] args) {
		SpringApplication.run(SimpleWebApplicationDemoApplication.class, args);
		
	}

}
