package com.nwmsu.DogDemo;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class SimpleWebApplicationDemoApplicationTests {

	@Test
	void contextLoads() {
	}

}
